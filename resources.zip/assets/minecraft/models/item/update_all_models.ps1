# 1. Проверить ключевые текстуры
$checkTextures = @("ak47.png", "revolver.png", "metal_fragments.png", "scrap.png")
foreach ($tex in $checkTextures) {
    if (Test-Path "RustResourcePack/assets/minecraft/textures/item/$tex") {
        Write-Host "✓ $tex существует" -ForegroundColor Green
    } else {
        Write-Host "✗ $tex ОТСУТСТВУЕТ!" -ForegroundColor Red
    }
}

# 2. Проверить pack.mcmeta
$pack = Get-Content "RustResourcePack/pack.mcmeta" -Raw | ConvertFrom-Json
if ($pack.pack.pack_format -eq 18) {
    Write-Host "✓ pack_format = 18" -ForegroundColor Green
} else {
    Write-Host "✗ pack_format должен быть 18" -ForegroundColor Red
}